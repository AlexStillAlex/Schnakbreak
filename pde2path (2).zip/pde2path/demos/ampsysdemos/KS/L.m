function l=L(k,p)
l=-(1-norm(k)^2)^2;