function l=L(k,p) 
q=p.q; l=-(1-norm(k)^2)^2*(1-(norm(k)/q)^2)^2; 
end 