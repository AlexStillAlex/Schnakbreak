function V=pot(x,s)
V=-1./cosh(x+s).^2-1./cosh(x-s).^2; 