cmds1: s=2, sig=1, ga=-2; subcritical, bif of ground state and 2ndary bif 
    to stable 2-hump; BP-cont in s, and DNS 
cmds3: s=1, sig=3, ga=-2; supercritical VK-crit violated at 2ndary bif 
    from ground state; DNS for different N 
cmds2: s=1.8, sig=2, ga=-2; critical case, for Exercise 
----------------
gpbra.m, standard; gpbra2.m, to show evals; 
gpbra3.m (shows difference to NLS-soliton, for Exercise)  