function plotall2(p) % convenience func to plot all 4 components 
plotsol(p,1,1,3); pause; plotsol(p,1,2,3); pause; plotsol(p,1,3,3); pause; plotsol(p,1,4,3); 
