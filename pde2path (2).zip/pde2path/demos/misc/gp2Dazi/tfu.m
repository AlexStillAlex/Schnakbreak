function y=tfu(x,m,n) 
% Laguerre ansatz function for multi-pol in gp 
y=x.^m.*exp(-x.^2/2); 