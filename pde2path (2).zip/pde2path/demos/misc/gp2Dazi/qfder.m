function qu=qfder(p,u) % 
qu=(p.mat.R*p.u(1:p.nu))';