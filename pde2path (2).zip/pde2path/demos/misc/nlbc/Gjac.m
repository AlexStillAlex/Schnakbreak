function [cj,aj,bj]=Gjac(p,u)  
cj=1; aj=p.eqn.a; bj=0; 