function [c,a,f,b]=G(p,u)  
c=1; a=p.eqn.a; f=0; b=0; 

