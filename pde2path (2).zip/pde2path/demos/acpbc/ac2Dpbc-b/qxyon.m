function p=qxyon(p)
p.nc.nq=2; p.fuha.qf=@qf; p.fuha.qfder=@qfder; p.nc.ilam=[2 4 5];