function p=qxon(p)
p.nc.nq=1; p.fuha.qf=@qfx; p.fuha.qfder=@qfxder; p.nc.ilam=[2 4];