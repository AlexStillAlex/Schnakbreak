function p=qyon(p)
p.nc.nq=1; p.fuha.qf=@qfy; p.fuha.qfder=@qfyder; p.nc.ilam=[2 5];