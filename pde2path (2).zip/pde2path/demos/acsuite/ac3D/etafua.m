function eta=etafua(p,np)
eta=np*0.000025; 