function eta=etafub(p,np)
eta=np*0.0001; 