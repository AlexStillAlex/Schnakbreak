function myticks(tit); 
fs=12; yticks([-3 3]); zticks([0 0.5 1]); 
title(tit,'fontsize',fs); 
set(gca,'fontsize',fs); 