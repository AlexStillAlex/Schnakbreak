function eta=etafub(p,np) % smaller eta, used for lam-cont. 
eta=np*1e-6; 